# servicenow-ticket
Serverless almbda functions with Secrets manager to create Service now ticket. 
